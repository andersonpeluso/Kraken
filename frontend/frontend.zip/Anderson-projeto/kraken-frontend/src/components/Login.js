import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api, { setAuthToken } from '../services/api';
import 'bootstrap/dist/css/bootstrap.min.css';

const Login = () => {
    const [usuario, setUsuario] = useState('');
    const [chave, setChave] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault(); // Impede o comportamento padr�o do formul�rio
        try {
            const response = await api.post('/OAuth/Autenticar', {}, {
                headers: { usuario, chave }, // Envia usu�rio e chave como headers
            });

            // Remove o prefixo "Bearer" do token recebido e salva no localStorage
            const token = response.data.token.replace('Bearer ', '');
            localStorage.setItem('token', token);

            // Exibe o token no console
            console.log('Token recebido e salvo no localStorage:', token);

            // Redireciona para a p�gina de produtos
            navigate('/');
        } catch (error) {
            console.error('Erro ao autenticar:', error.response || error);
            alert('Erro ao autenticar. Verifique suas credenciais.');
        }
    };



    return (
        <div className="d-flex justify-content-center align-items-center vh-100 bg-light">
            <div className="card p-4 shadow-sm" style={{ width: '24rem' }}>
                <h1 className="text-center mb-4">Login</h1>
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <form onSubmit={handleLogin}>
                    <div className="mb-3">
                        <label htmlFor="usuario" className="form-label">Usu�rio</label>
                        <input
                            id="usuario"
                            type="text"
                            className="form-control"
                            placeholder="Digite seu usu�rio"
                            value={usuario}
                            onChange={(e) => setUsuario(e.target.value)}
                            required
                        />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="chave" className="form-label">Chave</label>
                        <input
                            id="chave"
                            type="password"
                            className="form-control"
                            placeholder="Digite sua chave"
                            value={chave}
                            onChange={(e) => setChave(e.target.value)}
                            required
                        />
                    </div>
                    <button type="submit" className="btn btn-primary w-100">
                        Entrar
                    </button>
                </form>
            </div>
        </div>
    );
};

export default Login;
