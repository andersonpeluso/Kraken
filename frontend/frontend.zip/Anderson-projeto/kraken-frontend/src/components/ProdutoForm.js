import React, { useState } from 'react';

const ProdutoForm = ({ onSubmit }) => {
    const [nome, setNome] = useState('');
    const [categoria, setCategoria] = useState('');
    const [preco, setPreco] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        const produto = { nome, categoria, preco };
        onSubmit(produto);
        setNome('');
        setCategoria('');
        setPreco('');
    };

    return (
        <form onSubmit={handleSubmit}>
            <div className="mb-3">
                <label htmlFor="nome" className="form-label">Nome</label>
                <input
                    id="nome"
                    type="text"
                    className="form-control"
                    value={nome}
                    onChange={(e) => setNome(e.target.value)}
                    required
                />
            </div>
            <div className="mb-3">
                <label htmlFor="categoria" className="form-label">Categoria</label>
                <input
                    id="categoria"
                    type="text"
                    className="form-control"
                    value={categoria}
                    onChange={(e) => setCategoria(e.target.value)}
                    required
                />
            </div>
            <div className="mb-3">
                <label htmlFor="preco" className="form-label">Preço</label>
                <input
                    id="preco"
                    type="number"
                    className="form-control"
                    value={preco}
                    onChange={(e) => setPreco(e.target.value)}
                    required
                />
            </div>
            <button type="submit" className="btn btn-success w-100">Salvar Produto</button>
        </form>
    );
};

export default ProdutoForm;
