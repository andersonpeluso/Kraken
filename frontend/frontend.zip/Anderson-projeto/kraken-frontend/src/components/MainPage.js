import React from 'react';
import HomePage from './HomePage';

const MainPage = () => {
    return (
        <div className="bg-light vh-100">
            <HomePage />
        </div>
    );
};

export default MainPage;
