import React, { useState, useEffect } from 'react';
import api from '../services/api';

const HomePage = () => {
    const [produtos, setProdutos] = useState([]); // Estado para armazenar a lista de produtos
    const [mostrarFormulario, setMostrarFormulario] = useState(false); // Estado para exibir/ocultar o formulário

    // Função para buscar produtos
    const fetchProdutos = async () => {
        try {
            const response = await api.get('/Produto?quantidadePagina=1&registroPorPagina=10'); // Faz a requisição sem cabeçalhos de autenticação
            setProdutos(response.data); // Atualiza o estado com os produtos recebidos
        } catch (error) {
            console.error('Erro ao buscar produtos:', error.response || error);
        }
    };

    // useEffect para buscar produtos na montagem do componente
    useEffect(() => {
        console.log('Carregando produtos...');
        fetchProdutos();
    }, []); // Dependência vazia para executar apenas uma vez ao montar o componente

    // Função para adicionar produto
    const handleAddProduto = async (produto) => {
        try {
            await api.post('/Produto', produto); // Faz a requisição para adicionar um produto sem autenticação
            setMostrarFormulario(false); // Oculta o formulário após adicionar o produto
            fetchProdutos(); // Atualiza a lista de produtos
        } catch (error) {
            console.error('Erro ao adicionar produto:', error.response || error);
        }
    };

    return (
        <div className="container mt-5">
            <div className="d-flex justify-content-between align-items-center mb-4">
                <h1>Produtos</h1>
                <button
                    className="btn btn-primary"
                    onClick={() => setMostrarFormulario(!mostrarFormulario)}
                >
                    {mostrarFormulario ? 'Fechar Formulário' : 'Adicionar Produto'}
                </button>
            </div>

            {mostrarFormulario && (
                <div className="card p-4 mb-4">
                    <h2>Adicionar Produto</h2>
                    <form
                        onSubmit={(e) => {
                            e.preventDefault();
                            const nome = e.target.nome.value;
                            const categoria = e.target.categoria.value;
                            const preco = parseFloat(e.target.preco.value);
                            handleAddProduto({ nome, categoria, preco });
                        }}
                    >
                        <div className="mb-3">
                            <label htmlFor="nome" className="form-label">Nome</label>
                            <input type="text" id="nome" className="form-control" required />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="categoria" className="form-label">Categoria</label>
                            <input type="text" id="categoria" className="form-control" required />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="preco" className="form-label">Preço</label>
                            <input type="number" id="preco" className="form-control" required />
                        </div>
                        <button type="submit" className="btn btn-success">Salvar Produto</button>
                    </form>
                </div>
            )}

            <table className="table table-striped">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Categoria</th>
                        <th>Preço</th>
                    </tr>
                </thead>
                <tbody>
                    {produtos.length > 0 ? (
                        produtos.map((produto) => (
                            <tr key={produto.id}>
                                <td>{produto.nome}</td>
                                <td>{produto.categoria}</td>
                                <td>{produto.preco}</td>
                            </tr>
                        ))
                    ) : (
                        <tr>
                            <td colSpan="3" className="text-center">Nenhum produto encontrado</td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    );
};

export default HomePage;
