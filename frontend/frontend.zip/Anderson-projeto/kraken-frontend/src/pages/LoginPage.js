import React from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';

const LoginPage = () => {
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            // Simulação de login, pois a autenticação foi removida
            console.log('Login desativado, redirecionando para a Home...');
            navigate('/'); // Redireciona diretamente para a página de produtos
        } catch (error) {
            console.error('Erro ao fazer login:', error.response || error);
            alert('Erro ao fazer login. Verifique suas configurações.');
        }
    };

    return (
        <div className="container d-flex justify-content-center align-items-center" style={{ height: '100vh' }}>
            <div className="card p-4" style={{ width: '400px' }}>
                <h1 className="text-center">Login</h1>
                <form onSubmit={handleLogin}>
                    <div className="mb-3">
                        <label htmlFor="usuario" className="form-label">Usuário</label>
                        <input type="text" id="usuario" className="form-control" disabled /> {/* Desativado */}
                    </div>
                    <div className="mb-3">
                        <label htmlFor="chave" className="form-label">Chave</label>
                        <input type="password" id="chave" className="form-control" disabled /> {/* Desativado */}
                    </div>
                    <button type="submit" className="btn btn-primary w-100">Entrar</button>
                </form>
            </div>
        </div>
    );
};

export default LoginPage;
